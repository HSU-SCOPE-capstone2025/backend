package com.scope.backend.scope_api.service;

import com.scope.backend.scope_api.domain.frontend.*;
import com.scope.backend.scope_api.dto.frontend.InfluencerRecommendDto;
import com.scope.backend.scope_api.repository.frontend.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class InfluencerRecommendService {

    private final InfluencerRepository influencerRepository;
    private final InstagramRepository instagramRepository;
    private final YoutubeRepository youtubeRepository;
    private final TiktokRepository tiktokRepository;
    private final AdPriceRepository adPriceRepository;
    private final TotalFollowerRepository totalFollowerRepository;
    private final InstagramCommentRepository instagramCommentRepository;
    private final YoutubeCommentRepository youtubeCommentRepository;
    private final TiktokCommentRepository tiktokCommentRepository;

    public List<InfluencerRecommendDto> getAllInfluencers() {
        List<Influencer> influencers = influencerRepository.findAll();
        return influencers.stream().map(this::buildDto).collect(Collectors.toList());
    }

    private InfluencerRecommendDto buildDto(Influencer influencer) {
        // ✅ 각 플랫폼 별 이름 조회
        String instaName = instagramRepository.findFirstByInfluencerNumOrderByPostDateDesc(influencer.getInfluencerNum())
                .map(Instagram::getUserId).orElse(null);

        String youName = youtubeRepository.findFirstByInfluencerNumOrderByUploadDateDesc(influencer.getInfluencerNum())
                .map(Youtube::getChannelTitle).orElse(null);

        String tikName = tiktokRepository.findFirstByInfluencerNumOrderByUploadDateDesc(influencer.getInfluencerNum())
                .map(Tiktok::getUserId).orElse(null);

        // ✅ FSS 평균 계산
        float instaFss = (float) (instagramCommentRepository.findByPostUrlIn(instagramRepository.findAllByInfluencer_InfluencerNum(influencer.getInfluencerNum())
                        .stream().map(Instagram::getPostUrl).collect(Collectors.toList()))
                .stream().mapToDouble(InstagramComment::getFss).average().orElse(0.0) / 10);

        float tikFss = (float) (tiktokCommentRepository.findByVideoUrlIn(tiktokRepository.findAllByInfluencer_InfluencerNum(influencer.getInfluencerNum())
                        .stream().map(Tiktok::getVideoUrl).collect(Collectors.toList()))
                .stream().mapToDouble(TiktokComment::getFss).average().orElse(0.0) / 10);

        float youFss = (float) (youtubeCommentRepository.findByVideoUrlIn(youtubeRepository.findAllByInfluencer_InfluencerNum(influencer.getInfluencerNum())
                        .stream().map(Youtube::getVideoUrl).collect(Collectors.toList()))
                .stream().mapToDouble(YoutubeComment::getFss).average().orElse(0.0) / 10);

        // ✅ 팔로워 수 조회
        Long instaFollowers = totalFollowerRepository.findTopByInfluencerNumAndPlatformOrderByDateDesc(influencer.getInfluencerNum(), "Instagram")
                .map(TotalFollower::getSubscriberCount).orElse(0L);

        Long tikFollowers = totalFollowerRepository.findTopByInfluencerNumAndPlatformOrderByDateDesc(influencer.getInfluencerNum(), "Tiktok")
                .map(TotalFollower::getSubscriberCount).orElse(0L);

        Long youFollowers = totalFollowerRepository.findTopByInfluencerNumAndPlatformOrderByDateDesc(influencer.getInfluencerNum(), "YouTube")
                .map(TotalFollower::getSubscriberCount).orElse(0L);

        // ✅ 광고 가격 조회
        AdPrice adPrice = adPriceRepository.findByInfluencerNum(influencer.getInfluencerNum());

        // ✅ 클러스터링 최다수 추출
        List<String> instaPostUrls = instagramRepository.findAllByInfluencer_InfluencerNum(influencer.getInfluencerNum())
                .stream().map(Instagram::getPostUrl).collect(Collectors.toList());

        List<String> tikVideoUrls = tiktokRepository.findAllByInfluencer_InfluencerNum(influencer.getInfluencerNum())
                .stream().map(Tiktok::getVideoUrl).collect(Collectors.toList());

        List<String> youVideoUrls = youtubeRepository.findAllByInfluencer_InfluencerNum(influencer.getInfluencerNum())
                .stream().map(Youtube::getVideoUrl).collect(Collectors.toList());

        String tikCluster = tiktokCommentRepository.findTopClusterByVideoUrls(tikVideoUrls);
        String youCluster = youtubeCommentRepository.findTopClusterByVideoUrls(youVideoUrls);
        String instaCluster = instagramCommentRepository.findTopClusterByPostUrls(instaPostUrls);

        // ✅ DTO 빌딩
        return InfluencerRecommendDto.builder()
                .influencerName(influencer.getInfluencerName())
                .instaName(instaName)
                .youName(youName)
                .tikName(tikName)
                .categories(influencer.getCategories())
                .tag(influencer.getTags())
                .instaFss(instaFss)
                .tikFss(tikFss)
                .youFss(youFss)
                .instaFollowers(instaFollowers)
                .tikFollowers(tikFollowers)
                .youFollowers(youFollowers)
                .instaAd(adPrice.getAdPriceRangeInsta())
                .tikAd(adPrice.getAdPriceRangeTiktok())
                .youAd(adPrice.getAdPriceRangeYoutube())
                .tiktokCommentCluster(tikCluster)
                .youtubeCommentCluster(youCluster)
                .instagramCommentCluster(instaCluster)
                .build();
    }
}
