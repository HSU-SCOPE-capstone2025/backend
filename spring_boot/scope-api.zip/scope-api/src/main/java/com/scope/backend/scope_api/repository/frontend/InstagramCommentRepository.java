package com.scope.backend.scope_api.repository.frontend;

import com.scope.backend.scope_api.domain.frontend.InstagramComment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface InstagramCommentRepository extends JpaRepository<InstagramComment, Long> {
    @Query("SELECT ic.cluster FROM InstagramComment ic WHERE ic.postUrl IN :postUrls GROUP BY ic.cluster ORDER BY COUNT(ic.cluster) DESC LIMIT 1")
    String findTopClusterByPostUrls(@Param("postUrls") List<String> postUrls);

    @Query("SELECT ic FROM InstagramComment ic WHERE ic.postUrl IN :postUrls")
    List<InstagramComment> findByPostUrlIn(@Param("postUrls") List<String> postUrls);


}

