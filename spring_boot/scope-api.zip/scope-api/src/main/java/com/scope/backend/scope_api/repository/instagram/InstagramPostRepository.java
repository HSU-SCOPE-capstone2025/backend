//package com.scope.backend.scope_api.repository.instagram;
//
//import com.scope.backend.scope_api.domain.instagram.InstagramPost;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//
//@Repository
//public interface InstagramPostRepository extends JpaRepository<InstagramPost, Long> {
//}
