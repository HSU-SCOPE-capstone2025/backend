package com.scope.backend.scope_api.domain.frontend;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Entity
@Table(name = "instagram_comment")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class InstagramComment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "fss")
    private Float fss;

    @Column(name = "comment")
    private String comment;

    @Column(name = "comment_date")
    private LocalDate commentDate;

    @Column(name = "cluster")
    private Float cluster;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "post_url")
    private Instagram instagram;
}
