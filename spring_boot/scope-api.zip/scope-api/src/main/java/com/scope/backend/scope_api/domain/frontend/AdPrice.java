package com.scope.backend.scope_api.domain.frontend;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "ad_price")
@Data
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class AdPrice {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto Increment 설정
    @Column(name = "influencer_num")
    private Long influencerNum;

    @Column(name = "influencer_name")
    private String influencerName;

    @Column(name = "ad_price_range_insta")
    private String adPriceRangeInsta;

    @Column(name = "ad_price_range_tiktok")
    private String adPriceRangeTiktok;

    @Column(name = "ad_price_range_youtube")
    private String adPriceRangeYoutube;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "influencer_num")
    private Influencer influencer;


}
